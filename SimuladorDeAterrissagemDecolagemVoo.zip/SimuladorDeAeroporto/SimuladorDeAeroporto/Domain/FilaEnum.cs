﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorDeAeroporto.Domain
{
    public enum FilaEnum
    {
        Decolar = 1,
        Pousar = 2
    }
}