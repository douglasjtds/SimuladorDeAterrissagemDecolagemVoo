﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorDeAeroporto.Domain
{
    public enum PistaEnum
    {
        Pista1 = 1,
        Pista2 = 2,
        Pista3 = 3
    }
}